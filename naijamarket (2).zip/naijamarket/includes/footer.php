</main>
<footer class="bg-dark text-light py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h5 class="fw-bold"><i class="bi bi-shop"></i> <?= e(SITE_NAME) ?></h5>
                <p class="small mb-0"><?= e(SITE_TAGLINE) ?>. Empowering MSMEs across the 36 states of Nigeria and the FCT.</p>
            </div>
            <div class="col-md-3">
                <h6 class="fw-bold">Quick Links</h6>
                <ul class="list-unstyled small">
                    <li><a class="link-light" href="../index.php">Home</a></li>
                    <li><a class="link-light" href="../search.php">Browse Products</a></li>
                    <li><a class="link-light" href="../register.php">Open a Shop</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h6 class="fw-bold">Payments</h6>
                <p class="small mb-0">Paystack &amp; Flutterwave (test mode) • Bank transfer • Pay on delivery</p>
                <p class="small text-secondary mb-0">&copy; <?= date('Y') ?> <?= e(SITE_NAME) ?>. Built with PHP &amp; MySQL.</p>
            </div>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
